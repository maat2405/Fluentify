const express = require('express');
const cors = require('cors');
const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Initialize Gemini AI with proper configuration
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// API endpoint for sign language conversion
app.post('/api/convert', async (req, res) => {
    try {
        const { phrase } = req.body;
        
        if (!phrase) {
            return res.status(400).json({ error: 'Phrase is required' });
        }

        // Make sure we're using the correct model name and API version
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
        
        const prompt = `Please provide step-by-step instructions for expressing the following phrase in sign language: "${phrase}". 
        Format the response as clear, numbered steps.`;

        const result = await model.generateContent(prompt);
        const response = await result.response;
        const instructions = response.text()
            .split('\n')
            .filter(line => line.trim());
        
        res.json({ instructions });
    } catch (error) {
        console.error('API Error:', error);
        res.status(500).json({ 
            error: error.message || 'Failed to convert phrase',
            details: error.toString()
        });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
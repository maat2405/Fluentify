document.addEventListener('DOMContentLoaded', () => {
    const converterForm = document.getElementById('converterForm');
    const instructionsContainer = document.getElementById('instructionsContainer');
    const instructionsList = document.getElementById('instructionsList');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const resourcesList = document.getElementById('resourcesList');
    const statusDot = document.getElementById('statusDot');
    const statusText = document.getElementById('statusText');
    const translationText = document.getElementById('translationText');
    const waitingMessage = document.getElementById('waitingMessage');

    // Sample data for resources
    const resources = [
        {
            id: 1,
            title: "Basic Greetings",
            description: "Common signs for hello, goodbye, thank you",
            category: "basics",
            url: "https://www.handspeak.com/learn/70/"
        },
        {
            id: 2,
            title: "Numbers 1-10",
            description: "Learn to count in sign language",
            category: "basics",
            url: "https://www.lifeprint.com/asl101/pages-signs/n/numbers1-10.htm"
        },
        {
            id: 3,
            title: "Common Phrases",
            description: "Everyday expressions and their signs",
            category: "advanced",
            url: "https://www.startasl.com/sign-language-phrases/"
        },
        {
            id: 4,
            title: "Alphabet",
            description: "Learn the sign language alphabet",
            category: "basics",
            url: "https://www.lingvano.com/asl/blog/sign-language-alphabet/"
        },
        {
            id: 5,
            title: "Colors",
            description: "Common color signs",
            category: "basics",
            url: "https://lifeprint.com/asl101/pages-signs/c/colors.htm"
        }
    ];

    // Handle form submission
    converterForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const phraseInput = document.getElementById('phraseInput');
        const phrase = phraseInput.value.trim();

        if (!phrase) {
            alert('Please enter a phrase');
            return;
        }

        try {
            loadingIndicator.classList.remove('hidden');
            instructionsContainer.classList.add('hidden');

            const response = await fetch('/api/convert', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ phrase }),
            });

            const data = await response.json();

            if (response.ok) {
                displayInstructions(data.instructions);
            } else {
                throw new Error(data.error || 'Failed to convert phrase');
            }
        } catch (error) {
            console.error('Error details:', error);
            alert('Error: ' + error.message);
            
            // Clear previous instructions if there was an error
            instructionsContainer.classList.add('hidden');
            instructionsList.innerHTML = '';
        } finally {
            loadingIndicator.classList.add('hidden');
        }
    });

    // Display instructions
    function displayInstructions(instructions) {
        instructionsList.innerHTML = '';
        instructions.forEach((instruction, index) => {
            const li = document.createElement('li');
            li.textContent = instruction;
            li.className = 'instruction-item text-gray-700';
            li.style.animationDelay = `${index * 100}ms`;
            instructionsList.appendChild(li);
        });
        instructionsContainer.classList.remove('hidden');
    }

    // Handle tab switching
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            displayResources(button.dataset.category);
        });
    });

    // Display resources
    function displayResources(category) {
        const filteredResources = category === 'all' 
            ? resources 
            : resources.filter(r => r.category === category);
    
        resourcesList.innerHTML = filteredResources.map(resource => `
            <a href="${resource.url}" target="_blank" class="block resource-card hover:shadow-md">
                <h3 class="font-semibold">${resource.title}</h3>
                <p class="text-gray-600">${resource.description}</p>
                <div class="flex justify-between items-center mt-2">
                    <span class="text-sm text-blue-600">${resource.category}</span>
                    <span class="text-sm text-blue-600">Learn more →</span>
                </div>
            </a>
        `).join('');
    }
    // Initialize WebSocket connection
    function connectWebSocket() {
        try {
            const ws = new WebSocket(`ws://192.168.137.158:22`);
            
            ws.onopen = () => {
                console.log('Connected to Raspberry Pi');
                statusDot.classList.remove('bg-gray-400', 'bg-red-500');
                statusDot.classList.add('bg-green-500');
                statusText.textContent = 'Connected to device';
            };

            ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    waitingMessage.style.display = 'none';
                    translationText.textContent = data.translation || data.text || event.data;
                } catch (error) {
                    // Handle plain text messages
                    waitingMessage.style.display = 'none';
                    translationText.textContent = event.data;
                }
            };

            ws.onclose = () => {
                console.log('Disconnected from Raspberry Pi');
                statusDot.classList.remove('bg-green-500');
                statusDot.classList.add('bg-red-500');
                statusText.textContent = 'Disconnected - Retrying...';
                
                // Attempt to reconnect after 5 seconds
                setTimeout(connectWebSocket, 5000);
            };

            ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                statusDot.classList.remove('bg-green-500');
                statusDot.classList.add('bg-red-500');
                statusText.textContent = 'Connection error';
            };
        } catch (error) {
            console.error('WebSocket connection error:', error);
            statusText.textContent = 'Failed to connect';
            statusDot.classList.add('bg-red-500');
            
            // Attempt to reconnect after 5 seconds
            setTimeout(connectWebSocket, 5000);
        }
    }

    // Initial display of all resources
    displayResources('all');
    
    // Connect to the WebSocket
    connectWebSocket();
});